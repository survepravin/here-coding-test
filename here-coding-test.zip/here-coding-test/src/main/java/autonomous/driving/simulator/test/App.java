package autonomous.driving.simulator.test;

/**
 * Simulator App
 *
 */

public class App {

	public static void main( String[] args ) {
		Simulator simulator = new Simulator();
		simulator.action();
	}
}
