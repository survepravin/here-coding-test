package autonomous.driving.simulator.test;

/**
 * Available Drive Modes.
 *
 */
public enum DriveModes {
	A,
	B,
	C,
	D
}
